# ARE MCP server

Status: local owner-directed implementation candidate. Authority effect: none.

This package exposes the existing ARE and evolution-runtime JSON boundaries as
one local STDIO MCP server. It does not run a model, approve effects, activate a
cycle definition, bypass evolution admission, or create a second state machine.

## Tools

- `are_decide`: `route`, `context`, `effect`, and `continue` decisions with the
  existing caller-carried receipts.
- `evolution_status`: read-only coordinator phase inspection or durable-kernel
  diagnosis, so completed cycle tasks are visible to the desktop agent.
- `evolution_command`: exact kernel or coordination commands. Existing schema,
  revision, idempotency, admission, evidence, and effect-envelope checks apply.
- `evidence_get`: content-addressed object retrieval by SHA-256 and byte length;
  arbitrary filesystem paths are never accepted.

The configured evolution root owns objects, ledgers, receipts, and its rebuildable
index. The server caps request and response sizes. The kernel continues to reject
secret-bearing artifacts; tool outputs, credential dumps, and environment dumps
must not be submitted as evidence.

## Run in WSL

```sh
node implementation/agent-reasoning-engine/packages/are-mcp-server/bin/are-mcp-server.mjs \
  --evolution-root /absolute/path/to/are-evolution-state \
  --repository-root /home/vlad_/projects/cyberAlchemy-v2
```

For ChatGPT desktop on Windows, add a STDIO server named `are`. When the desktop
agent is Windows-native, use `wsl.exe` as the command and pass arguments that run
the Node entrypoint inside the selected distribution. When the agent itself runs
in WSL, use the WSL `node` path directly. Save and restart the desktop app; use
`/mcp` in a new chat to verify that all four tools are connected.

Example Windows-native command and arguments (replace the distribution and data
root if needed):

```text
command: wsl.exe
arguments: -d Ubuntu-26.04 --cd /home/vlad_/projects/cyberAlchemy-v2 -- /home/vlad_/.local/bin/node implementation/agent-reasoning-engine/packages/are-mcp-server/bin/are-mcp-server.mjs --evolution-root /home/vlad_/.local/share/are/evolution-runtime-v1 --repository-root /home/vlad_/projects/cyberAlchemy-v2
```

## Verification

```sh
npm test --prefix implementation/agent-reasoning-engine/packages/are-mcp-server
```

## Open Questions

- Which durable evolution root should become the long-lived operational root?
- Should desktop tool approval policy default to `writes` or `prompt` after the
  first real-client canary?
- When should this candidate be packaged as a private plugin rather than kept as
  a project-local MCP server?
