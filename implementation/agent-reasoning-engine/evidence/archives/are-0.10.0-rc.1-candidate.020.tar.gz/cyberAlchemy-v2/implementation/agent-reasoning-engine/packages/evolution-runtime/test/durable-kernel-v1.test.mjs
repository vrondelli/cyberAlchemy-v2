import assert from "node:assert/strict";
import {existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {join, resolve} from "node:path";
import {spawnSync} from "node:child_process";
import {fileURLToPath} from "node:url";
import test from "node:test";

import {
  createDurableEvolutionKernel,
  loadCandidateCycleDefinitionRegistry,
  materializeEvolutionCommand,
} from "../index.mjs";

const registry = loadCandidateCycleDefinitionRegistry();
const definition = registry.definitions.find((item) => item.definition_ref === "benchmark-research/v1");

function temporaryRoot() {
  return mkdtempSync(resolve(tmpdir(), "are-evolution-kernel-"));
}

function command(overrides = {}) {
  return materializeEvolutionCommand({
    idempotency_key: "kernel-test:diagnose:001",
    expected_event_revision: 0,
    actor: {actor_id: "agent:kernel-test", actor_kind: "agent"},
    worker_ref: null,
    cycle_ref: "cycle:kernel-test",
    cycle_definition_ref: definition.definition_ref,
    cycle_definition_digest: definition.definition_digest,
    operation: "cycle.diagnose",
    target: {record_kind: "experiment", record_ref: "experiment:kernel-test"},
    payload: {objective_ref: "objective:kernel-test"},
    ...overrides,
  });
}

const eventDraft = {event_type: "diagnosis-recorded", payload: {diagnosis_ref: "diagnosis:kernel-test", disposition: "active"}};

test("an accepted command commits once and reconstructs byte-identical three-layer state", () => {
  const root = temporaryRoot();
  try {
    const first = createDurableEvolutionKernel({root, require_enabled: false});
    const accepted = first.process(command(), {event_drafts: [eventDraft]});
    assert.equal(accepted.ok, true);
    assert.equal(accepted.disposition, "accepted");
    const before = first.inspect();
    const fresh = createDurableEvolutionKernel({root, require_enabled: false});
    const after = fresh.inspect();
    assert.deepEqual(after, before);
    assert.deepEqual(after.value, JSON.parse(readFileSync(new URL("../fixtures/durable-kernel-v1/three-layer-snapshot.json", import.meta.url))));
    assert.equal(after.value.aggregate_cycles.length, 1);
    assert.equal(after.value.subordinate_records.length, 1);
    assert.equal(after.value.executable_work.length, 1);
    assert.equal(after.value.aggregate_cycles[0].event_revision, 1);
    assert.equal(existsSync(join(root, "index", "evolution.sqlite")), true);
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test("exact duplicate commands replay their first receipt and changed bytes conflict", () => {
  const root = temporaryRoot();
  try {
    const kernel = createDurableEvolutionKernel({root, require_enabled: false});
    const first = kernel.process(command(), {event_drafts: [eventDraft]});
    const replay = kernel.process(command(), {event_drafts: [eventDraft]});
    assert.equal(replay.disposition, "replayed");
    assert.deepEqual(replay.value.receipt, first.value.receipt);
    assert.equal(kernel.inspect().value.commit_count, 1);
    const changed = command({payload: {objective_ref: "objective:changed"}});
    assert.deepEqual(kernel.process(changed, {event_drafts: [eventDraft]}).reason_codes, ["replay.conflict"]);
    assert.equal(kernel.inspect().value.commit_count, 1);
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test("the production-default kernel durably rejects disabled cycle definitions", () => {
  const root = temporaryRoot();
  try {
    const kernel = createDurableEvolutionKernel({root});
    const rejected = kernel.process(command(), {event_drafts: [eventDraft]});
    assert.equal(rejected.ok, true);
    assert.equal(rejected.disposition, "rejected");
    assert.deepEqual(rejected.value.receipt.reason_codes, ["command.definition-not-enabled"]);
    assert.equal(kernel.inspect().value.commit_count, 1);
    assert.equal(kernel.inspect().value.aggregate_cycles[0].event_revision, 0);
    assert.equal(definition.admission.enabled, false);
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test("the JSON stdin CLI keeps disabled definitions non-runnable", () => {
  const root = temporaryRoot();
  try {
    const request = {schema_version: "are.evolution-kernel-request/v1", operation: "process", command: command(), event_drafts: [eventDraft]};
    const cli = fileURLToPath(new URL("../bin/kernel.mjs", import.meta.url));
    const run = spawnSync(process.execPath, [cli, "--root", root], {input: JSON.stringify(request), encoding: "utf8"});
    assert.equal(run.status, 0, run.stderr);
    const output = JSON.parse(run.stdout);
    assert.equal(output.ok, true);
    assert.equal(output.disposition, "rejected");
    assert.deepEqual(output.value.receipt.reason_codes, ["command.definition-not-enabled"]);
    const unknown = spawnSync(process.execPath, [cli, "--root", root], {input: JSON.stringify({schema_version: "are.evolution-kernel-request/v1", operation: "inspect", root}), encoding: "utf8"});
    assert.equal(unknown.status, 2);
    assert.deepEqual(JSON.parse(unknown.stdout).reason_codes, ["kernel.request-invalid"]);
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test("concurrent stale expected revisions settle as one accepted and one rejected receipt", async () => {
  const root = temporaryRoot();
  try {
    const kernel = createDurableEvolutionKernel({root, require_enabled: false});
    const first = command({idempotency_key: "kernel-test:race:one"});
    const second = command({idempotency_key: "kernel-test:race:two", payload: {objective_ref: "objective:second"}});
    const [left, right] = await Promise.all([
      Promise.resolve().then(() => kernel.process(first, {event_drafts: [eventDraft]})),
      Promise.resolve().then(() => kernel.process(second, {event_drafts: [eventDraft]})),
    ]);
    assert.deepEqual([left.disposition, right.disposition], ["accepted", "rejected"]);
    assert.deepEqual(right.value.receipt.reason_codes, ["command.stale-revision"]);
    assert.equal(kernel.inspect().value.aggregate_cycles[0].event_revision, 1);
    assert.equal(kernel.inspect().value.commit_count, 2);
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test("SQLite loss is diagnosed and rebuilt solely from durable inputs", () => {
  const root = temporaryRoot();
  try {
    const kernel = createDurableEvolutionKernel({root, require_enabled: false});
    kernel.process(command(), {event_drafts: [eventDraft]});
    const expected = kernel.inspect().value;
    rmSync(join(root, "index", "evolution.sqlite"), {force: true});
    assert.equal(kernel.diagnose().value.disposition, "rebuild-required");
    const recovered = createDurableEvolutionKernel({root, require_enabled: false}).recover();
    assert.equal(recovered.ok, true);
    assert.deepEqual(recovered.value, expected);
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test("a stale writer lock blocks redispatch until explicit recovery removes it", () => {
  const root = temporaryRoot();
  try {
    const kernel = createDurableEvolutionKernel({root, require_enabled: false});
    const stale = {authority_effect: "none", nonce: "stale-test-lock", owner_id: "kernel:dead-process", process_id: 999999, schema_version: "are.evolution-kernel-writer-lock/v1"};
    writeFileSync(kernel.paths.lock, `${JSON.stringify(stale)}\n`, {mode: 0o600});
    assert.deepEqual(kernel.process(command(), {event_drafts: [eventDraft]}).reason_codes, ["kernel.writer-lock-held"]);
    const recovered = kernel.recover();
    assert.equal(recovered.ok, true);
    assert.equal(recovered.lock_recovery, "stale-lock-removed");
    assert.equal(kernel.process(command(), {event_drafts: [eventDraft]}).disposition, "accepted");
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test("missing or corrupt durable objects block recovery without trusting SQLite", () => {
  const root = temporaryRoot();
  try {
    const kernel = createDurableEvolutionKernel({root, require_enabled: false});
    kernel.process(command(), {event_drafts: [eventDraft]});
    const commitName = readFileSync(join(kernel.paths.commits, readdirSync(kernel.paths.commits).sort()[0]), "utf8");
    const commit = JSON.parse(commitName);
    const objectPath = join(kernel.paths.objects, commit.command_object.sha256.slice(0, 2), commit.command_object.sha256.slice(2));
    writeFileSync(objectPath, "corrupt");
    const recovered = createDurableEvolutionKernel({root, require_enabled: false}).recover();
    assert.equal(recovered.ok, false);
    assert.ok(recovered.reason_codes.some((code) => code.includes("OBJECT_CORRUPT")));
  } finally { rmSync(root, {recursive: true, force: true}); }
});

for (const point of ["after-objects", "after-ledger-entries", "after-commit", "after-index"]) {
  test(`crash point ${point} is recovered from commit visibility`, () => {
    const root = temporaryRoot();
    try {
      const crashing = createDurableEvolutionKernel({root, require_enabled: false, fault_injector(stage) { if (stage === point) throw new Error(`CRASH:${point}`); }});
      assert.throws(() => crashing.process(command(), {event_drafts: [eventDraft]}), new RegExp(`CRASH:${point}`));
      const fresh = createDurableEvolutionKernel({root, require_enabled: false});
      const recovered = fresh.recover();
      assert.equal(recovered.ok, true);
      assert.equal(recovered.value.commit_count, ["after-commit", "after-index"].includes(point) ? 1 : 0);
      if (["after-objects", "after-ledger-entries"].includes(point)) {
        const residue = fresh.diagnose().value.residue;
        assert.ok(residue.orphan_object_digests.length + residue.orphan_event_entries.length + residue.orphan_receipt_entries.length > 0);
      }
    } finally { rmSync(root, {recursive: true, force: true}); }
  });
}

test("recognized secrets never enter command or artifact durable storage", () => {
  const root = temporaryRoot();
  try {
    const kernel = createDurableEvolutionKernel({root, require_enabled: false});
    const secretCommand = command({payload: {api_key: "sk-example-secret-123456789"}});
    assert.deepEqual(kernel.process(secretCommand, {event_drafts: [eventDraft]}).reason_codes, ["secret-material-rejected"]);
    assert.equal(kernel.inspect().value.commit_count, 0);
    const artifact = kernel.putArtifact({bytes: "Authorization: Bearer abcdefghijklmnop", media_type: "text/plain", semantic_binding: {cycle_ref: "cycle:kernel-test", cycle_definition_digest: definition.definition_digest, role: "evidence", provenance_refs: ["source:test"], claim_ceiling: "test evidence only"}});
    assert.deepEqual(artifact.reason_codes, ["secret-material-rejected"]);
    assert.equal(kernel.diagnose().value.residue.orphan_object_digests.length, 0);
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test("non-secret artifacts are content addressed, verified, and deduplicated", () => {
  const root = temporaryRoot();
  try {
    const kernel = createDurableEvolutionKernel({root, require_enabled: false});
    const input = {bytes: "bounded benchmark evidence", media_type: "text/plain", semantic_binding: {cycle_ref: "cycle:kernel-test", cycle_definition_digest: definition.definition_digest, role: "evidence", provenance_refs: ["source:test"], claim_ceiling: "candidate evidence only"}};
    const first = kernel.putArtifact(input);
    const second = kernel.putArtifact(input);
    assert.equal(first.ok, true);
    assert.deepEqual(second, first);
    const loaded = kernel.readObject({sha256: first.value.sha256, byte_length: first.value.byte_length});
    assert.equal(Buffer.from(loaded.value.bytes_base64, "base64").toString("utf8"), input.bytes);
    assert.equal(kernel.diagnose().value.disposition, "rebuild-required");
    assert.equal(kernel.recover().ok, true);
    assert.deepEqual(kernel.diagnose().value.residue.orphan_object_digests, []);
  } finally { rmSync(root, {recursive: true, force: true}); }
});
