import {randomBytes, timingSafeEqual} from "node:crypto";
import {readFileSync, realpathSync} from "node:fs";
import {createServer} from "node:http";
import {extname, relative, resolve, sep} from "node:path";

import {freezeResult, isRecord, nonEmptyString} from "./canonical.mjs";

export const WINDOWS_CLIENT_STATE_SCHEMA = "are.codex-windows-client-state/v1";
export const WINDOWS_CLIENT_EVENT_SCHEMA = "are.codex-windows-client-event/v1";

const JSON_LIMIT = 128 * 1024;
const EVENT_LIMIT = 256 * 1024;
const APPROVAL_METHODS = new Set([
  "item/commandExecution/requestApproval",
  "item/fileChange/requestApproval",
  "item/permissions/requestApproval",
]);
const DECISIONS = new Set(["accept", "acceptForSession", "decline", "cancel"]);
const ASSET_TYPES = new Map([
  [".html", "text/html; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".css", "text/css; charset=utf-8"],
  [".svg", "image/svg+xml"],
]);

function secureEqual(left, right) {
  if (!nonEmptyString(left) || !nonEmptyString(right)) return false;
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

function json(response, status, body) {
  const value = `${JSON.stringify(body)}\n`;
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(value),
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
  });
  response.end(value);
}

function defaultApprovalResult(method) {
  if (method === "item/permissions/requestApproval") return {permissions: {}};
  return {decision: "decline"};
}

function normalizedApprovalResult(method, input) {
  if (method === "item/permissions/requestApproval") {
    if (input?.decision !== "decline") throw new TypeError("The prototype only permits declining explicit permission expansion requests.");
    return {permissions: {}};
  }
  if (!DECISIONS.has(input?.decision)) throw new TypeError("Unknown approval decision.");
  return {decision: input.decision};
}

export function createApprovalBroker(options = {}) {
  const timeoutMs = options.timeout_ms ?? 120000;
  const pending = new Map();
  let onChange = options.on_change ?? (() => {});

  function snapshot() {
    return [...pending.values()].map((entry) => freezeResult({
      request_id: entry.request_id,
      method: entry.method,
      params: entry.params,
      received_at: entry.received_at,
      expires_at: entry.expires_at,
    }));
  }

  function request(message) {
    if (!APPROVAL_METHODS.has(message?.method) || !Object.hasOwn(message ?? {}, "id")) {
      return Promise.resolve(defaultApprovalResult(message?.method));
    }
    const requestId = String(message.id);
    if (pending.has(requestId)) return Promise.resolve(defaultApprovalResult(message.method));
    return new Promise((resolveRequest) => {
      const receivedAt = new Date().toISOString();
      const entry = {
        request_id: requestId,
        method: message.method,
        params: structuredClone(message.params ?? {}),
        received_at: receivedAt,
        expires_at: new Date(Date.now() + timeoutMs).toISOString(),
        resolve: resolveRequest,
        timer: null,
      };
      entry.timer = setTimeout(() => {
        pending.delete(requestId);
        resolveRequest(defaultApprovalResult(entry.method));
        onChange({kind: "approval-expired", approval: freezeResult({...entry, resolve: undefined, timer: undefined})});
      }, timeoutMs);
      entry.timer.unref?.();
      pending.set(requestId, entry);
      onChange({kind: "approval-requested", approval: snapshot().find((value) => value.request_id === requestId)});
    });
  }

  function decide(requestId, input) {
    const entry = pending.get(String(requestId));
    if (!entry) return {ok: false, reason: "windows-client.approval-not-found"};
    let result;
    try { result = normalizedApprovalResult(entry.method, input); }
    catch (error) { return {ok: false, reason: "windows-client.approval-decision-invalid", detail: error.message}; }
    clearTimeout(entry.timer);
    pending.delete(String(requestId));
    entry.resolve(result);
    onChange({kind: "approval-resolved", request_id: String(requestId), decision: input.decision});
    return {ok: true, request_id: String(requestId), decision: input.decision, authority_effect: "none"};
  }

  function close() {
    for (const entry of pending.values()) {
      clearTimeout(entry.timer);
      entry.resolve(defaultApprovalResult(entry.method));
    }
    pending.clear();
  }

  return Object.freeze({request, decide, snapshot, close, set_on_change: (handler) => { onChange = handler; }});
}

async function readJsonBody(request) {
  let bytes = 0;
  const chunks = [];
  for await (const chunk of request) {
    bytes += chunk.length;
    if (bytes > JSON_LIMIT) throw new RangeError("request body exceeds the 128 KiB limit");
    chunks.push(chunk);
  }
  if (chunks.length === 0) return {};
  const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8"));
  if (!isRecord(parsed)) throw new TypeError("request body must be a JSON object");
  return parsed;
}

function confinedPath(root, candidate) {
  const realRoot = realpathSync(root);
  const realCandidate = realpathSync(candidate);
  const path = relative(realRoot, realCandidate);
  if (path === "" || (!path.startsWith(`..${sep}`) && path !== ".." && !path.includes(`${sep}..${sep}`))) return realCandidate;
  throw new RangeError("cwd must remain inside the configured repository root");
}

function publicInitialization(value) {
  if (!isRecord(value)) return null;
  return freezeResult({
    platform_family: value.platformFamily ?? null,
    platform_os: value.platformOs ?? null,
    user_agent: value.userAgent ?? null,
  });
}

export function createWindowsClientHost(options = {}) {
  const rpc = options.rpc_client;
  const approvals = options.approval_broker;
  if (!rpc?.initialize || !rpc?.notify || !rpc?.request || !rpc?.events) throw new TypeError("An app-server RPC client is required.");
  if (!approvals?.request || !approvals?.decide || !approvals?.snapshot) throw new TypeError("An approval broker is required.");
  const host = options.host ?? "127.0.0.1";
  if (!["127.0.0.1", "::1", "localhost"].includes(host)) throw new TypeError("The prototype host must bind to loopback.");
  const repositoryRoot = realpathSync(resolve(options.repository_root));
  const defaultCwd = confinedPath(repositoryRoot, resolve(options.default_cwd ?? repositoryRoot));
  const assetsRoot = realpathSync(resolve(options.assets_directory));
  const token = options.token ?? randomBytes(32).toString("base64url");
  const maxEvents = options.max_events ?? 512;
  const sseClients = new Set();
  const events = [];
  const threads = new Set();
  let eventSequence = 0;
  let initialization = null;
  let initialized = false;
  let closing = false;

  function publish(kind, payload) {
    let safePayload = payload;
    try {
      const encoded = JSON.stringify(payload);
      if (Buffer.byteLength(encoded) > EVENT_LIMIT) safePayload = {truncated: true, original_bytes: Buffer.byteLength(encoded)};
    } catch {
      safePayload = {unserializable: true};
    }
    const event = freezeResult({
      schema_version: WINDOWS_CLIENT_EVENT_SCHEMA,
      sequence: ++eventSequence,
      kind,
      payload: safePayload,
      observed_at: new Date().toISOString(),
      authority_effect: "none",
    });
    events.push(event);
    if (events.length > maxEvents) events.splice(0, events.length - maxEvents);
    const frame = `id: ${event.sequence}\nevent: message\ndata: ${JSON.stringify(event)}\n\n`;
    for (const client of sseClients) client.write(frame);
    return event;
  }

  approvals.set_on_change((event) => publish(event.kind, event));
  rpc.events.on("notification", (message) => publish("app-server-notification", message));
  rpc.events.on("continuity", (message) => publish("continuity", message));
  rpc.events.on("failure", (error) => publish("transport-failure", {code: error.code ?? null, message: error.message}));

  async function initialize() {
    if (initialized) return initialization;
    const value = await rpc.initialize({
      clientInfo: {name: "cyberalchemy_are_windows", title: "CyberAlchemy ARE Windows Client", version: "0.1.0"},
      capabilities: {experimentalApi: true},
    });
    await rpc.notify("initialized", {});
    initialization = publicInitialization(value);
    initialized = true;
    publish("client-initialized", initialization);
    return initialization;
  }

  function state() {
    return freezeResult({
      schema_version: WINDOWS_CLIENT_STATE_SCHEMA,
      ready: initialized && !closing,
      bind_host: host,
      repository_root: repositoryRoot,
      default_cwd: defaultCwd,
      initialization,
      thread_ids: [...threads],
      pending_approvals: approvals.snapshot(),
      last_event_sequence: eventSequence,
      authority_effect: "none",
    });
  }

  function authorized(request) {
    const header = request.headers.authorization;
    return typeof header === "string" && header.startsWith("Bearer ") && secureEqual(header.slice(7), token);
  }

  function serveAsset(pathname, response) {
    const relativePath = pathname === "/" ? "index.html" : pathname.slice(1);
    if (!["index.html", "app.js", "styles.css"].includes(relativePath)) return false;
    const assetPath = resolve(assetsRoot, relativePath);
    const body = readFileSync(assetPath);
    response.writeHead(200, {
      "content-type": ASSET_TYPES.get(extname(assetPath)) ?? "application/octet-stream",
      "content-length": body.length,
      "cache-control": "no-store",
      "content-security-policy": "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
      "referrer-policy": "no-referrer",
      "x-content-type-options": "nosniff",
      "x-frame-options": "DENY",
    });
    response.end(body);
    return true;
  }

  async function api(request, response, url) {
    if (!authorized(request)) return json(response, 401, {ok: false, reason: "windows-client.unauthorized"});
    if (request.method === "GET" && url.pathname === "/api/state") return json(response, 200, {ok: true, value: state()});
    if (request.method === "GET" && url.pathname === "/api/events") {
      response.writeHead(200, {
        "content-type": "text/event-stream; charset=utf-8",
        "cache-control": "no-store",
        connection: "keep-alive",
        "x-accel-buffering": "no",
      });
      response.write(": connected\n\n");
      const lastId = Number(request.headers["last-event-id"] ?? url.searchParams.get("after") ?? 0);
      for (const event of events) if (event.sequence > lastId) response.write(`id: ${event.sequence}\nevent: message\ndata: ${JSON.stringify(event)}\n\n`);
      sseClients.add(response);
      request.on("close", () => sseClients.delete(response));
      return;
    }
    const body = await readJsonBody(request);
    if (request.method === "POST" && url.pathname === "/api/threads") {
      const cwd = confinedPath(repositoryRoot, resolve(body.cwd ?? defaultCwd));
      const params = {
        cwd,
        approvalPolicy: body.approvalPolicy ?? "onRequest",
        sandbox: body.sandbox ?? "workspaceWrite",
        serviceName: "cyberalchemy_are_windows",
        ...(nonEmptyString(body.model) ? {model: body.model} : {}),
        ...(nonEmptyString(body.personality) ? {personality: body.personality} : {}),
      };
      const result = await rpc.startThread(params, {idempotency_key: body.requestKey});
      if (!nonEmptyString(result?.thread?.id)) throw new Error("thread/start did not return a thread identity");
      threads.add(result.thread.id);
      publish("thread-started", {thread: result.thread, instructionSources: result.instructionSources ?? []});
      return json(response, 201, {ok: true, value: result});
    }
    if (request.method === "POST" && url.pathname === "/api/threads/resume") {
      if (!nonEmptyString(body.threadId)) return json(response, 400, {ok: false, reason: "windows-client.thread-id-required"});
      const result = await rpc.request("thread/resume", {threadId: body.threadId}, {idempotency_key: body.requestKey});
      threads.add(body.threadId);
      publish("thread-resumed", {thread: result.thread});
      return json(response, 200, {ok: true, value: result});
    }
    if (request.method === "POST" && url.pathname === "/api/turns") {
      if (!nonEmptyString(body.threadId) || !threads.has(body.threadId)) return json(response, 409, {ok: false, reason: "windows-client.thread-not-loaded"});
      if (!nonEmptyString(body.text) || body.text.length > 65536) return json(response, 400, {ok: false, reason: "windows-client.turn-text-invalid"});
      const result = await rpc.request("turn/start", {threadId: body.threadId, input: [{type: "text", text: body.text}]}, {idempotency_key: body.requestKey});
      publish("turn-requested", {thread_id: body.threadId, turn_id: result?.turn?.id ?? null});
      return json(response, 202, {ok: true, value: result});
    }
    if (request.method === "POST" && url.pathname === "/api/turns/interrupt") {
      if (!nonEmptyString(body.threadId) || !nonEmptyString(body.turnId)) return json(response, 400, {ok: false, reason: "windows-client.turn-identity-required"});
      const result = await rpc.request("turn/interrupt", {threadId: body.threadId, turnId: body.turnId});
      publish("turn-interrupt-requested", {thread_id: body.threadId, turn_id: body.turnId});
      return json(response, 202, {ok: true, value: result});
    }
    const approvalMatch = request.method === "POST" ? url.pathname.match(/^\/api\/approvals\/([^/]+)$/) : null;
    if (approvalMatch) {
      const result = approvals.decide(decodeURIComponent(approvalMatch[1]), body);
      return json(response, result.ok ? 200 : 409, result);
    }
    return json(response, 404, {ok: false, reason: "windows-client.api-not-found"});
  }

  const server = createServer((request, response) => {
    const url = new URL(request.url ?? "/", `http://${host}`);
    if (request.method === "GET" && url.pathname === "/healthz") return json(response, 200, {ok: true, ready: initialized && !closing});
    if (url.pathname.startsWith("/api/")) {
      api(request, response, url).catch((error) => json(response, error instanceof SyntaxError || error instanceof TypeError || error instanceof RangeError ? 400 : 500, {
        ok: false,
        reason: "windows-client.request-failed",
        detail: error.message,
      }));
      return;
    }
    try {
      if (request.method === "GET" && serveAsset(url.pathname, response)) return;
    } catch (error) {
      return json(response, 500, {ok: false, reason: "windows-client.asset-failed", detail: error.message});
    }
    json(response, 404, {ok: false, reason: "windows-client.not-found"});
  });

  async function start() {
    await initialize();
    await new Promise((resolveStart, reject) => {
      server.once("error", reject);
      server.listen(options.port ?? 4317, host, () => {
        server.off("error", reject);
        resolveStart();
      });
    });
    const address = server.address();
    return freezeResult({
      schema_version: "are.codex-windows-client-ready/v1",
      host,
      port: address.port,
      url: `http://${host}:${address.port}/`,
      initialization,
      authority_effect: "none",
    });
  }

  async function close() {
    if (closing) return;
    closing = true;
    approvals.close();
    for (const response of sseClients) response.end();
    sseClients.clear();
    if (server.listening) await new Promise((resolveClose) => server.close(resolveClose));
    await rpc.close?.();
  }

  return Object.freeze({start, close, initialize, state, publish, token, server});
}
