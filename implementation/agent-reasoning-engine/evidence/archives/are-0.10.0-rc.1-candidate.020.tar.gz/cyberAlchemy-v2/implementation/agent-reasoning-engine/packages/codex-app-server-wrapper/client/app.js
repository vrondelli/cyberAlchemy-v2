const token = new URLSearchParams(location.hash.slice(1)).get("token");
const state = {threadId: null, turnId: null, lastSequence: 0, approvals: new Map(), agentNodes: new Map(), messageNodes: new Map()};
const elements = Object.fromEntries(["status", "cwd", "start-thread", "resume-id", "resume-thread", "thread-label", "approvals", "messages", "composer", "prompt", "send", "interrupt", "diagnostics"].map((id) => [id, document.getElementById(id)]));

function requestKey(prefix) {
  return `${prefix}:${crypto.randomUUID()}`;
}

async function api(path, options = {}) {
  if (!token) throw new Error("Missing launch token. Open the exact URL printed by the host.");
  const response = await fetch(path, {
    ...options,
    headers: {authorization: `Bearer ${token}`, "content-type": "application/json", ...(options.headers ?? {})},
  });
  const result = await response.json();
  if (!response.ok || result.ok === false) throw new Error(result.detail ?? result.reason ?? `HTTP ${response.status}`);
  return result.value ?? result;
}

function setStatus(text, ready = false) {
  elements.status.textContent = text;
  elements.status.className = `status ${ready ? "online" : "offline"}`;
}

function diagnostic(value) {
  elements.diagnostics.textContent = `${JSON.stringify(value, null, 2)}\n${elements.diagnostics.textContent}`.slice(0, 24000);
}

function message(role, text, id = crypto.randomUUID()) {
  let node = state.messageNodes.get(id);
  if (!node) {
    node = document.createElement("article");
    node.className = `message ${role}`;
    const label = document.createElement("span");
    label.textContent = role === "user" ? "You" : "ARE";
    const body = document.createElement("div");
    body.className = "message-body";
    node.append(label, body);
    elements.messages.append(node);
    state.messageNodes.set(id, node);
  }
  node.querySelector(".message-body").textContent = text;
  elements.messages.scrollTop = elements.messages.scrollHeight;
  return node;
}

function renderApprovals() {
  elements.approvals.replaceChildren();
  for (const approval of state.approvals.values()) {
    const card = document.createElement("article");
    card.className = "approval card";
    const title = document.createElement("strong");
    title.textContent = approval.method.split("/").at(-2) ?? "Approval";
    const detail = document.createElement("pre");
    detail.textContent = JSON.stringify(approval.params, null, 2);
    const actions = document.createElement("div");
    actions.className = "row end";
    const decline = document.createElement("button");
    decline.className = "secondary";
    decline.textContent = "Decline";
    decline.onclick = () => decideApproval(approval.request_id, "decline");
    actions.append(decline);
    if (approval.method !== "item/permissions/requestApproval") {
      const accept = document.createElement("button");
      accept.textContent = "Accept once";
      accept.onclick = () => decideApproval(approval.request_id, "accept");
      actions.append(accept);
    }
    card.append(title, detail, actions);
    elements.approvals.append(card);
  }
}

async function decideApproval(id, decision) {
  try {
    await api(`/api/approvals/${encodeURIComponent(id)}`, {method: "POST", body: JSON.stringify({decision})});
    state.approvals.delete(id);
    renderApprovals();
  } catch (error) { setStatus(error.message); }
}

function consume(event) {
  state.lastSequence = event.sequence;
  const payload = event.payload ?? {};
  if (event.kind === "approval-requested" && payload.approval) {
    state.approvals.set(payload.approval.request_id, payload.approval);
    renderApprovals();
  }
  if (["approval-resolved", "approval-expired"].includes(event.kind)) {
    const id = payload.request_id ?? payload.approval?.request_id;
    if (id) state.approvals.delete(id);
    renderApprovals();
  }
  if (event.kind !== "app-server-notification") return diagnostic(event);
  const notification = payload;
  if (notification.method === "turn/started") {
    state.turnId = notification.params?.turn?.id ?? state.turnId;
    elements.interrupt.disabled = !state.turnId;
    setStatus("Working", true);
  }
  if (notification.method === "item/agentMessage/delta") {
    const itemId = notification.params?.itemId ?? notification.params?.turnId ?? "agent-stream";
    const prior = state.agentNodes.get(itemId) ?? "";
    const next = `${prior}${notification.params?.delta ?? ""}`;
    state.agentNodes.set(itemId, next);
    message("agent", next, itemId);
  }
  if (notification.method === "item/completed" && notification.params?.item?.type === "agentMessage") {
    const item = notification.params.item;
    message("agent", item.text ?? "", item.id ?? notification.params?.turnId ?? "agent-complete");
  }
  if (notification.method === "turn/completed") {
    const turn = notification.params?.turn;
    for (const item of turn?.items ?? []) if (item?.type === "agentMessage" && typeof item.text === "string") message("agent", item.text, item.id ?? turn.id);
    state.turnId = null;
    elements.interrupt.disabled = true;
    setStatus(turn?.status === "completed" ? "Ready" : `Turn ${turn?.status ?? "ended"}`, true);
  }
  diagnostic(notification);
}

async function stream() {
  const response = await fetch(`/api/events?after=${state.lastSequence}`, {headers: {authorization: `Bearer ${token}`}});
  if (!response.ok || !response.body) throw new Error(`Event stream failed: HTTP ${response.status}`);
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const {value, done} = await reader.read();
    if (done) throw new Error("Event stream closed");
    buffer += decoder.decode(value, {stream: true});
    let boundary;
    while ((boundary = buffer.indexOf("\n\n")) >= 0) {
      const frame = buffer.slice(0, boundary);
      buffer = buffer.slice(boundary + 2);
      const data = frame.split("\n").find((line) => line.startsWith("data: "))?.slice(6);
      if (data) consume(JSON.parse(data));
    }
  }
}

async function load() {
  const snapshot = await api("/api/state");
  elements.cwd.value = snapshot.default_cwd;
  for (const approval of snapshot.pending_approvals) state.approvals.set(approval.request_id, approval);
  renderApprovals();
  setStatus("Ready", true);
  stream().catch(async (error) => {
    setStatus(error.message);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    stream().catch((next) => setStatus(next.message));
  });
}

elements["start-thread"].onclick = async () => {
  try {
    const result = await api("/api/threads", {method: "POST", body: JSON.stringify({cwd: elements.cwd.value, requestKey: requestKey("thread")})});
    state.threadId = result.thread.id;
    elements["thread-label"].textContent = state.threadId;
    elements.send.disabled = false;
  } catch (error) { setStatus(error.message); }
};

elements["resume-thread"].onclick = async () => {
  try {
    const threadId = elements["resume-id"].value.trim();
    const result = await api("/api/threads/resume", {method: "POST", body: JSON.stringify({threadId, requestKey: requestKey("resume")})});
    state.threadId = result.thread.id ?? threadId;
    elements["thread-label"].textContent = state.threadId;
    elements.send.disabled = false;
  } catch (error) { setStatus(error.message); }
};

elements.composer.onsubmit = async (event) => {
  event.preventDefault();
  const text = elements.prompt.value.trim();
  if (!text || !state.threadId) return;
  message("user", text);
  elements.prompt.value = "";
  elements.send.disabled = true;
  try {
    const result = await api("/api/turns", {method: "POST", body: JSON.stringify({threadId: state.threadId, text, requestKey: requestKey("turn")})});
    state.turnId = result.turn?.id ?? state.turnId;
    elements.interrupt.disabled = !state.turnId;
  } catch (error) { setStatus(error.message); }
  finally { elements.send.disabled = false; }
};

elements.interrupt.onclick = async () => {
  if (!state.threadId || !state.turnId) return;
  try { await api("/api/turns/interrupt", {method: "POST", body: JSON.stringify({threadId: state.threadId, turnId: state.turnId})}); }
  catch (error) { setStatus(error.message); }
};

load().catch((error) => setStatus(error.message));
