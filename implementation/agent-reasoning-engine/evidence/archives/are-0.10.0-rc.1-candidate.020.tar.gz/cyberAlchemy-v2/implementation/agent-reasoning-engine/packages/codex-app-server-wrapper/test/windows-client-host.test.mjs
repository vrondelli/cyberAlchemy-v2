import assert from "node:assert/strict";
import {EventEmitter} from "node:events";
import {mkdtempSync} from "node:fs";
import {resolve} from "node:path";
import test from "node:test";

import {createApprovalBroker, createWindowsClientHost, WINDOWS_CLIENT_STATE_SCHEMA} from "../index.mjs";

function fixture() {
  const calls = [];
  const events = new EventEmitter();
  const rpc = {
    events,
    initialize: async (params) => { calls.push(["initialize", params]); return {platformFamily: "unix", platformOs: "linux", userAgent: "fixture"}; },
    notify: async (method, params) => { calls.push(["notify", method, params]); },
    startThread: async (params) => { calls.push(["thread/start", params]); return {thread: {id: "thread-1"}, instructionSources: []}; },
    request: async (method, params) => {
      calls.push([method, params]);
      if (method === "thread/resume") return {thread: {id: params.threadId}};
      if (method === "turn/start") return {turn: {id: "turn-1", status: "inProgress"}};
      return {};
    },
    close: async () => { calls.push(["close"]); },
  };
  const broker = createApprovalBroker({timeout_ms: 1000});
  const repositoryRoot = mkdtempSync("/tmp/are-windows-client-test-");
  const assets = resolve(import.meta.dirname, "../client");
  const host = createWindowsClientHost({rpc_client: rpc, approval_broker: broker, repository_root: repositoryRoot, default_cwd: repositoryRoot, assets_directory: assets, port: 0, token: "test-token"});
  return {host, rpc, broker, calls, repositoryRoot};
}

async function request(ready, path, options = {}) {
  return fetch(`${ready.url.replace(/\/$/, "")}${path}`, {
    ...options,
    headers: {authorization: "Bearer test-token", "content-type": "application/json", ...(options.headers ?? {})},
  });
}

test("Windows client host initializes once and serves authenticated state", async (context) => {
  const value = fixture();
  const ready = await value.host.start();
  context.after(() => value.host.close());
  assert.equal((await fetch(`${ready.url}healthz`)).status, 200);
  assert.equal((await fetch(`${ready.url}api/state`)).status, 401);
  const response = await request(ready, "/api/state");
  const body = await response.json();
  assert.equal(body.value.schema_version, WINDOWS_CLIENT_STATE_SCHEMA);
  assert.equal(body.value.ready, true);
  assert.equal(value.calls.filter(([method]) => method === "initialize").length, 1);
  assert.equal(value.calls.some(([method]) => method === "notify"), true);
});

test("Windows client host starts a confined thread and turn", async (context) => {
  const value = fixture();
  const ready = await value.host.start();
  context.after(() => value.host.close());
  const threadResponse = await request(ready, "/api/threads", {method: "POST", body: JSON.stringify({cwd: value.repositoryRoot, requestKey: "thread:key"})});
  assert.equal(threadResponse.status, 201);
  const thread = await threadResponse.json();
  assert.equal(thread.value.thread.id, "thread-1");
  const turnResponse = await request(ready, "/api/turns", {method: "POST", body: JSON.stringify({threadId: "thread-1", text: "hello", requestKey: "turn:key"})});
  assert.equal(turnResponse.status, 202);
  assert.equal(value.calls.some(([method]) => method === "turn/start"), true);
  const escaped = await request(ready, "/api/threads", {method: "POST", body: JSON.stringify({cwd: "/tmp"})});
  assert.equal(escaped.status, 400);
});

test("approval broker supports command decisions and fail-closed permissions", async () => {
  const broker = createApprovalBroker({timeout_ms: 1000});
  const command = broker.request({id: 7, method: "item/commandExecution/requestApproval", params: {command: "npm test"}});
  assert.equal(broker.snapshot().length, 1);
  assert.equal(broker.decide("7", {decision: "accept"}).ok, true);
  assert.deepEqual(await command, {decision: "accept"});
  const permissions = broker.request({id: 8, method: "item/permissions/requestApproval", params: {permissions: {network: true}}});
  assert.equal(broker.decide("8", {decision: "accept"}).ok, false);
  assert.equal(broker.decide("8", {decision: "decline"}).ok, true);
  assert.deepEqual(await permissions, {permissions: {}});
});

test("Windows client host streams app-server notifications over authenticated SSE", async (context) => {
  const value = fixture();
  const ready = await value.host.start();
  context.after(() => value.host.close());
  const controller = new AbortController();
  const response = await request(ready, "/api/events", {signal: controller.signal});
  assert.equal(response.status, 200);
  value.rpc.events.emit("notification", {method: "turn/started", params: {turn: {id: "turn-1"}}});
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let observed = "";
  while (!observed.includes("turn/started")) observed += decoder.decode((await reader.read()).value);
  controller.abort();
  assert.match(observed, /are\.codex-windows-client-event\/v1/);
});
