// G02 candidate: unique-path clause ranking plus one-hop source neighbors.
// All reads are from the pinned base checkout; hints are not source evidence.
import {createRankedSourceAcquisition as createBase,rankSourcesTool} from './ranked-source-acquisition-base.mjs';
import {execFileSync} from 'node:child_process';
import {readFileSync,lstatSync} from 'node:fs';
import {join} from 'node:path';

export {rankSourcesTool};
const CODE=/\.(?:js|jsx|ts|tsx|go|py|rs|c|cc|cpp|h|hpp)$/i;
const CONTRACT=/(?:^|\/)(?:[^/]*\.schema\.(?:cue|json|ya?ml)|schema\.(?:cue|json|ya?ml))$/i;
const STOP=new Set(['about','after','before','could','current','expected','actual','issue','these','there','their','would','which','through','using','storage','config','configuration','should','validation','backend','recently','certain','fields']);

export function normalizeProblem(text){
  if(typeof text!=='string'||!text.length)throw Error('ranked-source.invalid-problem');
  if(text.startsWith('"')&&text.endsWith('"')){
    try{const decoded=JSON.parse(text);if(typeof decoded==='string')return decoded;}catch{}
  }
  if(!text.includes('\n')&&text.includes('\\n'))return text.replace(/\\r\\n|\\n/g,'\n');
  return text;
}

export function boundedClauses(text,maximumBytes=1024){
  const cleaned=normalizeProblem(text).replace(/<!--[\s\S]*?-->/g,' ').replace(/https?:\/\/\S+/g,' ');
  const lines=cleaned.split(/\n+/).map(line=>line.replace(/^\s*(?:[*-]|\d+[.)])\s*/,'').trim())
    .filter(line=>line&&!/^#{1,6}\s/.test(line)&&(line.length>=24||/`|\/api\//.test(line)));
  const clauses=[];
  for(const line of lines){
    let clause='';for(const character of line){if(Buffer.byteLength(clause+character)>maximumBytes)break;clause+=character;}
    if(clause&&!clauses.includes(clause))clauses.push(clause);
    if(clauses.length===8)break;
  }
  if(clauses.length)return clauses;
  const fallback=cleaned.trim().slice(0,maximumBytes);
  if(!fallback)throw Error('ranked-source.empty-primer');
  return [fallback];
}

function neighborhood({root,problem_statement,hints}){
  const paths=execFileSync('git',['ls-files','-z'],{cwd:root,encoding:'buffer',timeout:120000,maxBuffer:16*1024*1024})
    .toString('utf8').split('\0').filter(Boolean).sort();
  const tracked=new Set(paths);
  const seen=new Set(hints.map(h=>h.path));
  const terms=[...new Set((normalizeProblem(problem_statement).toLowerCase().match(/[a-z_][a-z0-9_]{2,}/g)??[])
    .filter(term=>!STOP.has(term)&&term.length>=3))].slice(0,64);
  const candidates=[];
  const add=(path,kind)=>{
    if(!tracked.has(path)||seen.has(path)||candidates.some(x=>x.path===path))return;
    let stat;try{stat=lstatSync(join(root,path));}catch{return;}
    if(!stat.isFile()||stat.size>256*1024)return;
    const lines=readFileSync(join(root,path),'utf8').split(/\r?\n/);
    const matched=terms.filter(term=>lines.some(line=>line.toLowerCase().includes(term)));
    if(kind==='contract'&&matched.length<2)return;
    let best=0,bestCount=-1;
    for(let i=0;i<lines.length;i++){
      const count=matched.filter(term=>lines[i].toLowerCase().includes(term)).length;
      if(count>bestCount){best=i;bestCount=count;}
    }
    candidates.push({path,start_line:Math.max(1,best-7),end_line:Math.min(lines.length,best+9),
      matched_terms:matched.slice(0,8),score_units:matched.length+(kind==='sibling'?8:0),kind});
  };
  for(const hint of hints){
    if(hint.path.endsWith('_test.go'))add(hint.path.replace(/_test\.go$/,'.go'),'sibling');
    if(hint.path.endsWith('.test.js'))add(hint.path.replace(/\.test\.js$/,'.js'),'sibling');
  }
  for(const path of paths)if(CONTRACT.test(path))add(path,'contract');
  candidates.sort((a,b)=>b.score_units-a.score_units||a.path.localeCompare(b.path));
  const siblings=candidates.filter(x=>x.kind==='sibling').slice(0,2);
  const contracts=candidates.filter(x=>x.kind==='contract').slice(0,2);
  return [...siblings,...contracts].map(({kind,...hint})=>hint);
}

export function createRankedSourceAcquisition(options){
  const clauses=boundedClauses(options.problem_statement);
  const base=createBase({...options,problem_statement:clauses[0]});
  const queries=clauses.map(clause=>base.query(clause));
  const hints=[],seen=new Set();
  const add=hint=>{if(hint&&!seen.has(hint.path)){hints.push(hint);seen.add(hint.path);}};
  for(const kind of [true,false])for(let round=0;round<2;round++)for(const result of queries){
    if(hints.length>=20)break;
    add(result.hints.find(hint=>CODE.test(hint.path)===kind&&!seen.has(hint.path)));
  }
  for(const result of queries)for(const hint of result.hints){if(hints.length>=20)break;add(hint);}
  const neighbors=neighborhood({...options,hints});
  const combined=[];const combinedSeen=new Set();
  const include=hint=>{if(hint&&!combinedSeen.has(hint.path)){combined.push(hint);combinedSeen.add(hint.path);}};
  for(const hint of hints.slice(0,8))include(hint);
  for(const hint of neighbors)include(hint);
  for(const hint of hints)if(combined.length<20)include(hint);
  const primer={...base.primer,hints:combined.slice(0,20)};
  const summary='Deterministic pinned-base leads, including unique-path and source-neighborhood candidates; not evidence. '+
    'Inspect relevant code, schema/contract and sibling implementation leads with read_file before relying on them. '+
    'Do not select a path solely because it is listed: '+JSON.stringify(primer.hints.map(
      ({path,start_line,end_line,matched_terms})=>({path,start_line,end_line,matched_terms})));
  if(Buffer.byteLength(summary)>16384)throw Error('ranked-source.primer-too-large');
  return Object.freeze({query:base.query,primer,summary});
}
