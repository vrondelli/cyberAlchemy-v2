"""Exposed Go screen for receipt-bound source plus narrow final evidence."""
import importlib.util
import pathlib

ROOT = pathlib.Path('/opt/are-benchmark-runs/g02-narrow-final-evidence-go-r3')
source = ROOT / 'code/run_go.py'
spec = importlib.util.spec_from_file_location('g02_packet_go_base', source)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.ROOT = ROOT
runner.NAME = 'are-g02-narrow-final-evidence-go-r3'
runner.BASE_OVERLAY = 'code/base-overlay.mjs'
runner.HASHES = {
    **runner.HASHES,
    'code/deepseek-full-window-profile.mjs':
        'c3cbe527db03480124adf0f9dd1daf7b93deefa790674cbc1e0ce00f2f9b3af2',
    'code/episode-recovery-v2.mjs':
        'cf087c74cfc6c06148a8427b2165d465b4c78a810657178392841bf976dc3f30',
    'code/ranked-source-acquisition.mjs':
        '946c2b42d4e332bc3266244c2bcfe95d044020e3451b212b0ad74bb16f9cd171',
    'code/base-overlay.mjs':
        'e924fce63ef783781b8361e8225fb9bc71756005ad9d4e0d5af8b0ebf2939dbd',
    'code/orchestrate-recovery-v2.mjs':
        '837a48a3947b37dd1e955fab56db7c929d172bd68cdf472fc78f14677dfd64e2',
    'code/initial-source-packet.mjs':
        '4202f3f6c178a4009b9173c8a4a72e3116932d876578884a0ee85832c41eb207',
}

original_save = runner.save
original_run = runner.subprocess.run


def save(path, value):
    if path.name == 'STARTED.json':
        value = {**value,
            'hypothesis': 'receipt-bound pinned-base source plus narrow final read guidance improves Go span and file selection within twenty calls',
            'control': {'span_f1': 0.2571044675848169, 'file_f1': 0.7368421052631579,
                        'model_tokens': 648011, 'wall_seconds': 298.0718116760254},
            'success': 'valid native selection; both F1 metrics strictly above same-instance DSH; fewer tokens and less wall time'}
    original_save(path, value)


def run(args, *positional, **keywords):
    if isinstance(args, list) and args[:2] == ['docker', 'run']:
        image_index = args.index(runner.IMAGE)
        prefix = '/repo/' + runner.C
        extra = [
            '-v', str(ROOT / 'code/orchestrate-recovery-v2.mjs') + ':' + prefix + '/discovery-v1/orchestrate-recovery-v2.mjs:ro',
        ]
        args = args[:image_index] + extra + args[image_index:]
    return original_run(args, *positional, **keywords)


runner.save = save
runner.subprocess.run = run

if __name__ == '__main__':
    runner.main()
