# DomainSpec CLI candidate

Local-only AlchLang parser, compiler and guarded action runtime.

```bash
domainspec build customer-approval.md --out generated
domainspec run customer-approval.md ReleaseCredit \
  --actor CreditOperator \
  --facts '{"customerId":"c-1","riskScore":600,"status":"approved","amount":100}' \
  --grant credit-release-authority \
  --adapter memory
```

Execute the declared SQLite transactional Outbox effect with an explicit
infrastructure request:

```bash
domainspec run examples/outbox-operation.md CommitOrderWithOutbox \
  --actor OrderService \
  --facts '{"operationId":"operation-1","orderId":"order-1","status":"pending","outboxMessageId":"message-1","occurredAt":"2026-09-03T12:00:00.000Z","payload":{"kind":"order-committed"}}' \
  --grant order-transaction-authority \
  --binding sqlite-transactional-outbox \
  --database ./outbox.sqlite \
  --effect-request-file examples/outbox-request.json

domainspec outbox pending --database ./outbox.sqlite
domainspec outbox dispatch --database ./outbox.sqlite --transport stdout \
  --worker-id local-worker
```

`run` validates the action, rules, permission, authority grant, `performs`
edge, effect, provider binding, guarantee, rollback continuation, aggregate
type and event types before committing. It never dispatches the message.
Dispatch is a separate explicit command.

Discover operation patterns before requesting generation:

```bash
domainspec patterns
domainspec patterns --available
domainspec patterns --blocked
domainspec pattern operation-port
```

Availability is derived from the registered meta-type, integration binding,
generator and conformance prerequisites. Blocked patterns remain visible but
`domainspec pattern <id>` fails closed for them. Pattern registration does not
make an architecture pattern stable; stability remains owner-controlled.

The CLI defaults to non-networked local execution. Its Outbox dispatcher has a
stdout transport and a separately invoked HTTP transport that rejects every
origin not both allowlisted and confirmed on the command line. Programmatic
consumers may inject memory, SQLite or allowlisted HTTP adapters. Every action
requires explicit rules, permission, authority grant and adapter or effect
binding.

The durable SQLite provider adds expiring claim/lease ownership, exponential
retry, attempt ceilings, dead letter and explicit requeue, replay
reconciliation, v1-to-v2 row-preserving migration, runtime telemetry, and a
transactional consumer inbox. Inspect every state with:

```bash
domainspec outbox status --database ./outbox.sqlite --status dead
domainspec outbox requeue-dead --database ./outbox.sqlite \
  --message-id message-1 --now 2026-09-03T12:10:00.000Z
```

HTTP dispatch is opt-in and requires three matching values: the endpoint's
origin, `--allow-origin`, and `--confirm-network-dispatch`:

```bash
domainspec outbox dispatch --database ./outbox.sqlite --transport http \
  --worker-id http-worker --endpoint https://events.example.test/outbox \
  --allow-origin https://events.example.test \
  --confirm-network-dispatch https://events.example.test
```

The provider remains a candidate local proof. It does not claim high
availability, multi-region behavior, exactly-once delivery, stable pattern
promotion, release or production operations.
