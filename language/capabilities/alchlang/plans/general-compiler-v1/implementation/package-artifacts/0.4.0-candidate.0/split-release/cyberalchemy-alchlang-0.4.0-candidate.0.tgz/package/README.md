# @cyberalchemy/alchlang

AlchLang parser, ontology compiler and Node/TypeScript build surface.

This package does not contain Cargo templates, Rust compilation, local-host, Ansible, or Bubblewrap integration.

Status: candidate. Packaging is local candidate evidence and grants no release, publication, deployment, or authority effect.

## Open Questions

- What owner decision will admit a version for publication?
- Which portability evidence is required before the experimental local-host package can leave the repository?
