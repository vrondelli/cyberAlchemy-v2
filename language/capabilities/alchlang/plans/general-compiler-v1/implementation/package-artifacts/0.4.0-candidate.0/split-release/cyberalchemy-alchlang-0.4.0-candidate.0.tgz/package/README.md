# @cyberalchemy/alchlang

AlchLang parser, exact authoring compiler and Node/TypeScript application build surface.

Use `alchlang check <application.alch>` and `alchlang build <application.alch> --out <new-directory>`. The installed DomainSpec bridge requires the exact optional peer package or `ALCHLANG_DOMAINSPEC_PACKAGE_ROOT`.

The exact candidate file allowlist and export map are recorded in the source package's `package-boundaries.json`. Packaging is local construction evidence only and grants no publication, release, deployment, product approval, production claim, or authority effect.

## Open Questions

- P02 owns installation and execution from these archives in clean consumers.
- What owner decision will admit one frozen candidate for product validation?
