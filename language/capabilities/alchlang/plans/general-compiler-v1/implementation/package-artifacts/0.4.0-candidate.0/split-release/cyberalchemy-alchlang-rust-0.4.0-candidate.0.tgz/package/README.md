# @cyberalchemy/alchlang-rust

Optional native Rust generation and conformance layer for AlchLang.

Use `alchlang-rust check <file.alch>` for Rust profiles. Cargo and the locked native toolchain are required only for native build or conformance operations.

The exact candidate file allowlist and export map are recorded in the source package's `package-boundaries.json`. Packaging is local construction evidence only and grants no publication, release, deployment, product approval, production claim, or authority effect.

## Open Questions

- P02 owns installation and execution from these archives in clean consumers.
- What owner decision will admit one frozen candidate for product validation?
