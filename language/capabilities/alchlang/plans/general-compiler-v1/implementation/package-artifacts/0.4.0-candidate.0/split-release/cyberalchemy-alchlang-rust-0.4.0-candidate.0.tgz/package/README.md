# @cyberalchemy/alchlang-rust

Optional native Rust backend for AlchLang.

This package is optional. Building native targets requires the repository-locked Rust toolchain and Cargo cache.

Status: candidate. Packaging is local candidate evidence and grants no release, publication, deployment, or authority effect.

## Open Questions

- What owner decision will admit a version for publication?
- Which portability evidence is required before the experimental local-host package can leave the repository?
