# @cyberalchemy/alchlang-local-host

Experimental repository-bound local deployment host for AlchLang.

This experimental package requires the CyberAlchemy checkout provisioning runtime. It is not a portable public host or production deployment surface.

Status: experimental-repository-bound. Packaging is local candidate evidence and grants no release, publication, deployment, or authority effect.

## Open Questions

- What owner decision will admit a version for publication?
- Which portability evidence is required before the experimental local-host package can leave the repository?
