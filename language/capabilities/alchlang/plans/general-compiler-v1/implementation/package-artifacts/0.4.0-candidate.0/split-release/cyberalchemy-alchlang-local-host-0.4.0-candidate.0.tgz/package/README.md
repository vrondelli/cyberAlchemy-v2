# @cyberalchemy/alchlang-local-host

Experimental repository-bound local host layer for AlchLang.

Use `alchlang-local-host check <file.alch>` for the experimental local-host profiles. This package is repository-bound and is not a portable or production deployment surface.

The exact candidate file allowlist and export map are recorded in the source package's `package-boundaries.json`. Packaging is local construction evidence only and grants no publication, release, deployment, product approval, production claim, or authority effect.

## Open Questions

- P02 owns installation and execution from these archives in clean consumers.
- What owner decision will admit one frozen candidate for product validation?
