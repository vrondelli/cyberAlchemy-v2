# DomainSpec CLI candidate

Local-only AlchLang parser, compiler and guarded action runtime.

```bash
domainspec build customer-approval.md --out generated
domainspec run customer-approval.md ReleaseCredit \
  --actor CreditOperator \
  --facts '{"customerId":"c-1","riskScore":600,"status":"approved","amount":100}' \
  --grant credit-release-authority
```

The CLI does not connect to external services. Programmatic consumers may inject
memory, SQLite or allowlisted HTTP adapters. Every action requires explicit
rules, permission, authority grant and adapter binding.
