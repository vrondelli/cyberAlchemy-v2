# DomainSpec CLI candidate

Local-only AlchLang parser, compiler and guarded action runtime.

```bash
domainspec build customer-approval.md --out generated
domainspec run customer-approval.md ReleaseCredit \
  --actor CreditOperator \
  --facts '{"customerId":"c-1","riskScore":600,"status":"approved","amount":100}' \
  --grant credit-release-authority \
  --adapter memory
```

Execute the declared SQLite transactional Outbox effect with an explicit
infrastructure request:

```bash
domainspec run examples/outbox-operation.md CommitOrderWithOutbox \
  --actor OrderService \
  --facts '{"operationId":"operation-1","orderId":"order-1","status":"pending","outboxMessageId":"message-1","occurredAt":"2026-09-03T12:00:00.000Z","payload":{"kind":"order-committed"}}' \
  --grant order-transaction-authority \
  --binding sqlite-transactional-outbox \
  --database ./outbox.sqlite \
  --effect-request-file examples/outbox-request.json

domainspec outbox pending --database ./outbox.sqlite
domainspec outbox dispatch --database ./outbox.sqlite --transport stdout
```

`run` validates the action, rules, permission, authority grant, `performs`
edge, effect, provider binding, guarantee, rollback continuation, aggregate
type and event types before committing. It never dispatches the message.
Dispatch is a separate explicit command.

Discover operation patterns before requesting generation:

```bash
domainspec patterns
domainspec patterns --available
domainspec patterns --blocked
domainspec pattern operation-port
```

Availability is derived from the registered meta-type, integration binding,
generator and conformance prerequisites. Blocked patterns remain visible but
`domainspec pattern <id>` fails closed for them. Pattern registration does not
make an architecture pattern stable; stability remains owner-controlled.

The CLI does not connect to external services. Its Outbox dispatcher supports
only a local stdout transport. Programmatic consumers may inject memory, SQLite
or allowlisted HTTP adapters. Every action requires explicit rules, permission,
authority grant and adapter or effect binding.

The SQLite runtime is a candidate local proof. It does not yet implement
claim/lease, backoff, dead letter, consumer inbox/idempotency, network
transports, online migrations, HA or production operations.
